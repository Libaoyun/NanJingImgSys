package com.rdexpense;

import com.common.util.CheckParameter;

/**
 * @auther luxiangbao
 * @date 2021/11/30 11:59
 * @describe
 */
public class Test {


    public static void main(String[] orgs){

     String d = "2021年";

     System.out.println(d.substring(0,4));


    }
}
